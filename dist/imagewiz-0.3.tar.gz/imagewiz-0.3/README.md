# imageWiz Module
A simple framework for handling the more mundane parts of image processing.